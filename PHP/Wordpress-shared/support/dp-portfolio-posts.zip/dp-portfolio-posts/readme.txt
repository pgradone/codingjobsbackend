This plugin is licensed under the General Public License (GPL). You will find a 
copy of the GPL in the 'license' directory of this plugin.

This plugin is maintained and updated to work with the latest version of the Divi theme to the best of our ability. We have no control over Divi theme updates. For that reason, installation of any Divi updates should be made on a test server before being made to a live site. This is good practice for any theme/plugin. If a conflict is found with our plugin and the Divi theme, we will work to resolve the issue and release an update as soon as possible. 