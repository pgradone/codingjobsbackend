<?php

class Dp_PP_Activator {

    public static function activate() {
        
    }

}
