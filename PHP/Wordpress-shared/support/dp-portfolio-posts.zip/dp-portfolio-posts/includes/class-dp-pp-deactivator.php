<?php

class Dp_PP_Deactivator {

    public static function deactivate() {
        
    }

}
