<?php

/*
Plugin Name: Example Super Plugin
Description: It's a super plugin you must have !!!!
Author: Me (WF3)
Version: 1.0
*/

//call the action to render the image in the footer
add_action('get_footer', 'esp_render_footer');

/**
 * renders an image
 */
function esp_render_footer()
{
  //debug like that:
  /* die('hello test');
  exit;
   */

  //create the path to the image in our plugin directory
  $img = plugins_url('img/logo.jpg', __FILE__);

  //renders html for the image
  echo '<img style="width:200px; margin: 0px auto;" margin="auto" src="' . $img . '" />';
}



//Create a new shortcode named [logo]
add_shortcode('logo', 'esp_shortcode_logo');

// renders the [logo] shorcode
function esp_shortcode_logo($atts)
{
  //create the path to the image in our plugin directory
  $img = plugins_url('img/logo.jpg', __FILE__);

  //renders html for the image
  return '<img style="width:200px; margin: 0px auto;" margin="auto" src="' . $img . '" />';
}
